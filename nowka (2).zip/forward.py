"""
TO DO:

Wnisokowanie
    a) przod

    wybieramy X czynnikow. Wybieramy wartosci dla kazdego z czynnika. Dla poszczegolnych wartosci
    znajdujemy wszystki rezultaty. Jesli dla kazdego rekordu wniosek jest ten sam przyjmujemy go za
    odpowiedz. Jesli nie to nie ma odpowiedzi / zbyt malo czynnikow

    {czynnik: [odp1, odp2, odp3], czynnik2: [odp1, odp2, odp3], czynnik3: [odp1, odp2, odp3]}


    b)

"""