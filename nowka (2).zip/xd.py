zmienne = ['A', 'B', 'C', 'D', 'E']

