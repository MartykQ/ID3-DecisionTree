tablica = ["pies", "kot", "pies"]


indices = [i for i, x in enumerate(tablica) if x == "pies"]

print(indices)