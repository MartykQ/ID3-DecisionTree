# ID3-DecisionTree
Python implementation of ID3 with tree drawing using Graphviz

<h1>INPUT</h1>
<br>
<img src="https://github.com/MartykQ/ID3-DecisionTree/blob/master/images/input.PNG">

<h1>OUTPUT</h1>
<img src="https://github.com/MartykQ/ID3-DecisionTree/blob/master/images/output.PNG">
